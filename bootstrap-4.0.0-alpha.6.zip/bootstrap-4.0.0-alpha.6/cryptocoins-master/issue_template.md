To request icons for your coin, please fill info below:

---

### Coin name (`TICKER`)

* link to logo: 
* official website: 

**Optional info** (not mandatory, but saves me time):

* logo color (HEX): `#xxxxxx`
* bitcointalk.org thread: 

---

**Please note:** This is all completely voluntary work, so if you want to _support my efforts and speed up_ the addition of your coin, please donate. Donation addresses can be found [on my website](https://allien.work/donate)
